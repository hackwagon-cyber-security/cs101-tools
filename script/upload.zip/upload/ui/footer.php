<div class="ui inverted vertical footer segment">
  <div class="ui container">
    <div class="ui stackable inverted divided equal height stackable grid">
      <div class="three wide column">
        <h4 class="ui inverted header">Customer Care</h4>
        <div class="ui inverted link list">
          <a href="#" class="item">Sitemap</a>
          <a href="#" class="item">Contact Us</a>
          <!-- <a href="#" class="item">Religious Ceremonies</a>
          <a href="#" class="item">Gazebo Plans</a> -->
        </div>
      </div>
      <div class="three wide column">
        <h4 class="ui inverted header">Shopedia</h4>
        <div class="ui inverted link list">
          <a href="#" class="item">About Shopedia</a>
          <a href="#" class="item">Sell on Shopedia</a>
          <a href="#" class="item">Terms &amp; Conditions</a>
          <a href="#" class="item">Privacy Policy</a>
        </div>
      </div>
      <div class="seven wide column">
        <h4 class="ui inverted header">Exclusive Deals and Offers!</h4>
        <p>Subscribe and be the first to get awesome deals!</p>
        <div class="ui action input">
          <input type="text" placeholder="Your email address">
          <!-- <select class="ui compact selection dropdown">
            <option value="none">Gender</option>
            <option selected="male" value="articles">Male</option>
            <option value="female">Female</option>
          </select> -->
          <div class="ui teal button">SIGN ME UP</div>
        </div>

        
      </div>
    </div>
  </div>
</div>